
From Tanya & Xueling: 

...[we] generated intervals and gene lists for T2D and QT GWAS loci.

1) We started with a comprehensive list of index SNPs (compiled by Anne, Alisa, Heather, and others).  The list included all known associations (p<5e-8) in any population.  Number of associated markers:
	- anthropometric (BMI,obesity,WC,Weight,WHR,etc.), 128 markers
	- biomarker (adiponectin,creatinine,eGFRcrea), 91 markers
	- bloodpressure (DBP,SBP,HTN,MAP,PP), 128 markers
	- glycemic (2hGlu,FGlu,FIns,Fproinsulin,HbA1C, and BMI-adjusted traits), 132 markers
	- height, 260 markers
	- lipids (CHOL,HDL,LDL,TG), 489 markers
	- T2D, 185 markers
Some of these markers are associated in multiple populations (e.g. both European and African American).  Each SNP/population pair was treated independently.

2) For each SNP/population pair, I did the following:
	- Identify the most distant pair of SNPs with r^2 > .5 (using 1000G Phase I data for the appropriate population: EUR, AMR, or ASN)
	- Move an additional .02 cM upstream and downstream of the most distant SNPs with r^2 > .5
	- Add an additional 300 kb on either side of the interval
To calculate LD appropriately, I mapped populations showing association to 1000G samples as follows:
	- European => EUR
	- East Asian => ASN
	- African American => AMR
	- Hispanic => AMR
	- South Asian => ASN
	- Micronesian => ASN

3) Next, for each trait, I merged any overlapping intervals.  For example, at KCNJ11, I merged 3 intervals, generated based on rs5215 association in Europeans, rs5219 association in Europeans, and rs5219 association in African Americans.  The set of non-overlapping intervals are given in:
	- merged_intervals.anthropometric, 72 intervals
	- merged_intervals.biomarker, 53 intervals
	- merged_intervals.bloodpressure, 42 intervals
	- merged_intervals.glycemic, 69 intervals
	- merged_intervals.height, 185 intervals
	- merged_intervals.lipids, 154 intervals
	- merged_intervals.T2D, 73 intervals
The files contain the following columns:
	- Trait (e.g. T2D)
	- Chromosome (1-22,X)
	- Interval_start
	- Interval_end
	- Comment -- list of each SNP (with trait and population showing association) that falls within the region

4) For each trait, I pulled the list of all genes in the refFlat table (hg19) that overlapped or were contained within any interval.  Gene lists are given in the following files:
	- gene_list.anthropometric, 573 genes
	- gene_list.biomarker, 639 genes
	- gene_list.bloodpressure, 473 genes
	- gene_list.glycemic, 699 genes
	- gene_list.height, 1988 genes
	- gene_list.lipids, 2290 genes
	- gene_list.T2D, 611 genes
The files contain the following columns:
	- gene name
	- gene strand (direction of transcription)
	- chr
	- Interval_start
	- Interval_end
	- distance from interval to gene (always 0 since I required a gene to at least partially overlap the interval)
	- direction (always "overlap" or "within" ... other possible values are "upstream" and "downstream" if you allow for genes nearby, but not within the interval -- not relevant here)
	- txStart (transcription start for gene)
	- txEnd (transcription end for gene)

For the vast majority of markers, this was straightforward.  However, a number of markers were not found or were monomorphic in the 1000G Phase I data, so we couldn't calculate LD.  We dealt with these in a few different ways:
	- For 6 markers, there was another marker at the locus that was associated at the same locus.  Since the locus would be represented, we ignored these markers.
	- For 15 markers, Xueling identified proxies.  However, for all but 4 of those, the proxy was monomorphic in 1000G data, so we couldn't calculate LD.  We added the remaining 11 markers to the "missing" list (described next).
	- For 24 markers (including the 11 from the previous step), we defined an interval based on the mean interval size for all markers in the 1000G data, and we centered that interval around the index SNP.  From step 2 above, the mean and median interval sizes are 779076.8 bp and 717393 bp, respectively.  We used the mean interval size to be more inclusive.
	- There were 2 markers (rs3228890 associated with creatinine and rs7826222 associated with WC) that were absent from the 1000G data, had no known proxies, and did not have position in UCSC tables.  We dropped those two markers.

