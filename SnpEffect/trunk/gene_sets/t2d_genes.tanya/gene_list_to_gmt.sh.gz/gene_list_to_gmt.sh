#!/bin/sh

for g in gene_list.*
do
	study=`echo $g | cut -f 2 -d '.' `
	geneSet=T2D_GENES_`echo $study | tr '[a-z]' '[A-Z]'`

	(
		echo $geneSet ;
		echo "Genes in LD with $study GWAS loci";
		cut -f 1 $g | sort | uniq ;
	) | tr "\n" "\t"
	echo
		
done
