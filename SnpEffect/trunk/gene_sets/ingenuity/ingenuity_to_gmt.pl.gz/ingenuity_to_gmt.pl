#!/usr/bin/perl

$debug = 0;


while( $l = <STDIN> ) {
	chomp $l;
	($gene, $set) = split /\t/, $l;

	if( $gene ne '' ) {
		if( $gs{$set} ne '' )	{ $gs{$set} .= "\t$gene"; }
		else					{ $gs{$set} = "$set\tingenuity.set\t$gene"; }

		print "gs{$set}\t$gene\n" if $debug;
	}
}

foreach $set ( sort keys %gs ) { print "$gs{$set}\n"; }
